<?php
    include('../Model/Db.php');
    session_start();
    error_reporting(0);
    if(isset($_POST['name']) && isset($_POST['email']) && isset($_POST['dob']) )
    {
        $data = file_get_contents('./Data.json');
        $myJSON = json_decode($data, true);

        foreach($myJSON as $key=>$user)
        {
            if($user['username'] == $_SESSION['username'])
            {
                $myJSON[$key]['name'] = $_POST['name'];
                $myJSON[$key]['email'] = $_POST['email'];
                $myJSON[$key]['gender'] = $_POST['gender'];
                $myJSON[$key]['dob'] = $_POST['dob'];

                $newJSON = json_encode($myJSON);
                file_put_contents('./Data.json', $newJSON);
            }
        }
        $connection = new db();
        $connObj = $connection->OpenCon();

        $result = $connection->UpdateUser($connObj, "users", $_SESSION['id'], $_POST['name'], $_POST['email'], $_POST['gender'], $_POST['dob']);
        $_SESSION['name'] = $_POST['name'];
        $_SESSION['email'] = $_POST['email'];                
        $_SESSION['gender'] = $_POST['gender'];                                
        $_SESSION['dob'] = $_POST['dob'];                                                
        $_SESSION['username'] = $_POST['name'];

        if($result){
            header("location:../Views/Creator_Profile.php");
        }
        else{
            echo "Error Occurred while updating!";
        }
    }
    else
    {
        echo "field cannot be empty";
    }
?>