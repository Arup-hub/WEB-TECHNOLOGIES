<?php

    session_start();
        header("location:Login.php");
    session_destroy();

?>