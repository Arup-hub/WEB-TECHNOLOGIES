<?php

    session_start();

    if(!(isset($_SESSION["username"]) && isset($_SESSION["password"]))){
        header("location:login.php");
        $_SESSION["login"] = false;
    }

    if ( isset( $_REQUEST ) && !empty( $_REQUEST ) ) {
 if (
 isset( $_REQUEST['Check'] ) &&
  !empty( $_REQUEST['Email'] ) &&
  !empty( $_REQUEST['Subject'] )
 ) {
  
  echo "*Request list"; 
 } 
 else {
 echo "*Request not found";
 }
}

    include("./includes/header.php");

?>

<style>

body {
  background-color: lightblue;
}
body {
     margin: 0;
     padding: 3em 0;
     background: lightblue;
     font-family: Georgia, Times New Roman, serif;
    }
 
    #container {
     width: 600px;
     height: 400px;
     background: lightblue;
     border: 3px solid black;
     -webkit-border-radius: 3px;
     -moz-border-radius: 3px;
     -ms-border-radius: 3px;
     border-radius: 3px;
     border-top: 3px solid black;
     padding: 1em 2em;
     margin: 0 auto;
     
    }
</style>
</fieldset>
    <h2 align="center"> CHECK CREATOR REQUEST </h2> 
<fieldset>

</body>
</html>
<!DOCTYPE html>
<html>
<head>
<style>
 
</style>
</head>
<body>

  <div id="container">
    <form action="" method="post" novalidate>
     <ul>
      <br><br>
      <br><br><br><br>
     <li><input type="submit" name="Check" id="Check" value="Check" /></li>
    </ul>
    <ul>

  <li><a href='./Dashboard.php'>Go Back</a></li>
</ul>
   </form>
  </div>

</body>
</html>
<script type="text/javascript"></script>

<?php include("./includes/footer.php"); ?>