<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chnage Pasword</title>
</head>
<body>
    <style>
body {
  background-color: lightblue;
}
</style>
    
    <?php include('./Header.php'); ?>
    <fieldset>
    <table align="right">
    <tr>
        <td>
            <nav>
                <a href="./Dashboard.php">Home</a> ||
                <a href="./Login.php">Log in</a> ||
                <a href="./Registration.php">Registration</a>
            </nav>
        </td>
    </tr>        
    </table>
    </fieldset>
    
        <form action='./changepasscheck.php' method="POST" novalidate>
            <fieldset>
                        
                <legend>
                    <b>Change Password</b>
                </legend>
               
                    
                        <label>Current Password:</label>
                    <input type='password' name='current' required/>
                    
                    <br><br>
                        <label> New Password:</label>
                        <input type='password' name='new' required/>
                    <br><br>
                        <label>Retype New Password:</label>
                        <input type='password' name='cnp' required/>
                    
                    <br><br>
                    
                    <input type='submit' value="Confirm">

                    <ul>

  <li><a href='./Dashboard.php'>Go Back</a></li>
</ul>
                    
                
            </fieldset>
        </form>
    
    <?php include('./Footer.php'); ?>
</body>
</html>
