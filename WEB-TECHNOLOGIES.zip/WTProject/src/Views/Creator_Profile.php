<?php 
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $_SESSION['name']; ?></title>
</head>
<body>
    <fieldset>
        <style>
body {
  background-color: lightblue;
}
</style>
    <?php include('./Header.php'); ?>
    
                    
    
       
            Logged in as <a href="./Creator_Profile.php">
            <?php 
            echo isset( $_SESSION['name']); ?> </a> ||
            <a href="./Logout.php">Log Out</a>
        
        <br>
    </fieldset>
    <table border="1px solid black" width='100%'>
        <tr>
            <td border="1px solid black">
               <label ><b>Menu</b></label> 
               <hr>
                
                
                <ul>
                    <li><a href='./Dashboard.php'>Home</a></li>
                    <li><a href='./Creator_Profile.php'>Profile View</a></li>
                    <li><a href='./editprofile.php'>Update Profile</a></li>
                    <li><a href='./Add.php'>Add new Admin</a></li>
                    <li><a href='./notice.php'>Send SMS / Notice</a></li>
                    <li><a href='./changepassword.php'>Change Password</a></li>
                    <li><a href='./m.php'>View All Users Details</a></li>
                    <li><a href='./Logout.php'>Logout</a></li>
                </ul>
            </td>
            <td>
                        <fieldset>
                <legend>
                    <b>PROFILE VIEW</b>
                </legend>
                <form action='./editp.php' method="POST">
                    <table align="center" border="1px solid black" width='60%'>
                        <td align="center" width='47%'>
                            <b>Name:</b>
                        </td>
                        <td align="center" width='47%'>
                            <?php echo $_SESSION['name']; ?>
                        </td>
                    </tr>
                    <tr>
                        <td align="center" width='47%'>
                            <b>Email:</b>
                        </td>
                        <td align="center" width='47%'>
                            <?php echo $_SESSION['email']; ?>
                        </td>
                    </tr>
                    <tr>
                        <td align="center" width='47%'>
                            <b>Gender:</b>
                        </td>
                        <td align="center" width='47%'>
                            <?php echo $_SESSION['gender']; ?>
                        </td>
                    </tr>
                    <tr>
                        <td align="center" width='47%'>
                            <b>Date of Birth:</b>
                        </td>
                        <td align="center" width='47%'>
                            <?php echo $_SESSION['dob']; ?>
                        </td>
                    </tr>
                    <tr>   
                    </tr>
                </table>
                <br>
            </td>
        </tr>
    </table>
     <fieldset>
    <?php include('./Footer.php'); ?>
</body>
</html>