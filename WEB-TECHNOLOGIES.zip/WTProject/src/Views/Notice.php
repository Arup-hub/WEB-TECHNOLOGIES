<?php
 session_start();
 include("./includes/header.php");
if ( isset( $_REQUEST ) && !empty( $_REQUEST ) ) {
 if (
 isset( $_REQUEST['Email'], $_REQUEST['Subject'], $_REQUEST['Send'] ) &&
  !empty( $_REQUEST['Email'] ) &&
  !empty( $_REQUEST['Subject'] )
 ) {
  $message = wordwrap( $_REQUEST['Send'], 70 );
  $to = $_REQUEST['Email'] . '@' . $_REQUEST['Subject'];
  $result = @mail( $to, '', $message );
  print '*Message was sent to ' . $to;
 } else {
  print '*Not all information was submitted.';
 }
}
?>
<!DOCTYPE html>
 <head>
   <meta charset="utf-8" />
   <style>
    body {
     margin: 0;
     padding: 3em 0;
     background: lightblue;
     font-family: Georgia, Times New Roman, serif;
    }
 
    #container {
     width: 800px;
     background: lightblue;
     border: 1px solid black;
     -webkit-border-radius: 5px;
     -moz-border-radius: 5px;
     -ms-border-radius: 5px;
     border-radius: 5px;
     border-top: 1px solid black;
     padding: 1em 2em;
     margin: 0 auto;
     
    }
 
    ul {
     list-style: none;
     padding: 0;
    }
 
    ul > li {
     padding: 0.12em 1em
    }
 
    label {
     display: block;
     float: left;
     width: 150px;
    }
 
    input, textarea {
     font-family: Georgia, Serif;
    }
   </style>
  </head>
  <body>
   <div id="container">
    <h1>Sending SMS / Notice</h1>
    <form action="" method="post" novalidate>
     <ul>
      <li>
       <label for="Email">Email</label>
       <input type="text" name="Email" id="Email" placeholder="abcde@gmail.com" /></li>
      <li>
      <label for="Subject">Subject</label>
       <input type="text" name="Subject" id="Subject" />
      </li>
      <li>
       <label for="smsMessage">Message/Text</label>
       <textarea name="smsMessage" id="smsMessage" cols="45" rows="15"></textarea>
      </li>
     <li><input type="submit" name="Send" id="Send" value="Send" /></li>
    </ul>
    <ul>

  <li><a href='./Dashboard.php'>Go Back</a></li>
</ul>
   </form>
  </div>
 </body>
</html>
<?php include("./includes/footer.php"); ?>