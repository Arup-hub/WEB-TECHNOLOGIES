<?php
    session_start();
   
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
</head>
<body>
    <style>
body {
  background-color: lightblue;
}
</style>
    <?php include('./Header.php'); ?>
    <fieldset>
       
Logged in as <a href="./Creator_Profile.php"><?php echo isset($_SESSION['name']); ?></a> 
           
        
    <br>
    </fieldset>
    <table border="1px solid black" width='100%'>
        <tr>
            <td>
                <label>Menu</label>
                <br>
                <hr>
                <ul>
                    <li><a href='./Dashboard.php'>Home</a></li>
                    <li><a href='./Creator_Profile.php'>Profile View</a></li>
                    <li><a href='./editprofile.php'>Update Profile</a></li>
                    <li><a href='./Add.php'>Add new Admin</a></li>
                    <li><a href='./request.php'>Check Creator Request</a></li>
                    <li><a href='./notice.php'>Send SMS / Notice</a></li>
                    <li><a href='./changepassword.php'>Change Password</a></li>
                    <li><a href='./m.php'>View All Users Details</a></li>
                    <li><a href='./Logout.php'>Logout</a></li>
                </ul>
            </td>
            <td>
                <fieldset>
                <legend>
                    <b>UPDATE PROFILE</b>
                </legend>

                <form action='./editp.php' method="POST" novalidate>
                    <table align="center" border="1px solid black" width='60%'>
                        <tr>
                            <td width='40%' align="right">
                                Name:
                            </td>
                            <td>

                                <input type='text' name = 'name' value="<?php echo $_SESSION['name']; ?>" required/>
                            </td>
                        </tr>
                        <tr>
                            <td align="right">
                                Email:
                            </td>
                            <td>
                                <input type='email' name = 'email' value="<?php echo $_SESSION['email']; ?>" required/>
                            </td>
                        </tr>

                        <tr>
                            <td align="right">
                                Gender:
                            </td>
                            <td>
                                <input type='text' name = 'gender' value="<?php echo $_SESSION['gender']; ?>" required/>
                            </td>
                        </tr>

                        <tr>
                            <td align="right">
                                Date of birth:
                            </td>
                            <td>
                                <input type='date' name = 'dob' value="<?php echo $_SESSION['dob']; ?>" required/>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <center>
                                    <input type='submit' value="Submit">
                                </center>
                            </td>
                        </tr>
                    </table>
                </form>
                <br>
            </td>
        </tr>
    </table>
    <fieldset>
    <?php include('./Footer.php'); ?>
</body>
</html>