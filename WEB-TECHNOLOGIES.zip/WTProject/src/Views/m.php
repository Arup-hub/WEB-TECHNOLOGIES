<?php

    session_start();
    
    include("../controllers/login_controller.php");

    if(isset($_SESSION["login"]) && $_SESSION["login"] == false){
        echo "* User not found";
        unset($_SESSION["login"]);
    }

    include("./includes/Header.php");
?>
<!DOCTYPE html>
<html>
<head>
<style>

body {
  background-color: lightblue;
}

</style>
</head>
<body>
<fieldset>
                <legend>
                    <b>VIEW ALL USERS DETAILS</b>
                </legend>

                <form action='./editp.php' method="POST">
                    <table align="center" border="1px solid black" width='60%'>


<div class="row">
  <div>
    <p>Name:Arup__Email:arup.1447@gmail.com__Username:Arup__Gender:male__DOB: 15/12/2022</p>
  </div>
  <div>
    <p>Name:Ratan__Email:ratan.1447@gmail.com__Username:Ratan__Gender:male__DOB: 16/12/2022</p>
  </div>
</div>

<div class="row">
  <div>
    <p>Name:Paul__Email:paul.1447@gmail.com__Username:Paul__Gender:male__DOB: 17/12/2022</p>
  </div>
  <div>
       <p>Name:asd__Email:asd.1447@gmail.com__Username:Asd__Gender:male__DOB: 18/12/2022</p>
  </div>
  <ul>

  <li><a href='./Dashboard.php'>Go Back</a></li>
</ul>
</body>
</html>

</fieldset>

<?php include("./includes/footer.php"); ?>

