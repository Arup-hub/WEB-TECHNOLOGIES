<?php

    session_start();

    if(!(isset($_SESSION["username"]) && isset($_SESSION["password"]))){
        header("location:login.php");
        $_SESSION["login"] = false;
    }

    include("./includes/header.php");

?>
<style>
body {
  background-color: lightblue;
}
</style>
<fieldset>
    <br>
        <nav>
            Logged in as <?php  echo  $_SESSION["username"]; ?></a> ||
            <a href="./logout.php">Log Out</a>
        </nav>
        <br>
    </fieldset>
    <h2 align="center"> Welcome <?php if(isset($_SESSION['username'])): ?> <?php echo $_SESSION["username"]; ?> <?php endif; ?> </h2> 
<fieldset>
    <table >
        <tr>
            <td >
                <label>Features:</label>
                <br>
                
               <ul>
                    
                    <li><a href='./Creator_Profile.php'>Profile View</a></li>
                    <li><a href='./editprofile.php'>Update Profile</a></li>
                    <li><a href='./Add.php'>Add new Admin</a></li>
                    <li><a href='./request.php'>Check Creator Request</a></li>
                    <li><a href='./notice.php'>Send SMS / Notice</a></li>
                    <li><a href='./changepassword.php'>Change Password</a></li>
                    <li><a href='./m.php'>View All Users Details</a></li>
                    <li><a href='./logout.php'>Logout</a></li>
               </ul>

            </td>
            <td >
                <table align="center" >
                
                    <br><br><br>

                </table>
                <br>
            </td>
        </tr>
    </table>
</fieldset>

<?php include("./includes/footer.php"); ?>

