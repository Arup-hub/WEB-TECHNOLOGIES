<?php

    session_start();
    
    include("../controllers/login_controller.php");

    if(isset($_SESSION["login"]) && $_SESSION["login"] == false){
        echo "* User not found";
        unset($_SESSION["login"]);
    }

    include("./includes/Header.php");
?>
    <style>
body {
  background-color: lightblue;
}
</style>
    <form method="post" novalidate onsubmit="return validateForm(this);">
        <fieldset>

            <label for="username">Username: </label>
            <input id="username" name="username" type="text"
            value="<?php if(isset($_COOKIE["username"])) { echo $_COOKIE["username"]; } ?>"
            class="input-field">
            <span id="username_error"></span>
            <br>

            <label for="password" >Password:</label>
            <input id="password" name="password" type="password"
            value="<?php if(isset($_COOKIE["password"])) { echo $_COOKIE["password"]; } ?>"
            class="input-field">
            <span id="password_error"></span>
            <br>

            <?php

                if(isset($_COOKIE["remember_checkbox"])){
                    echo "<input checked type='checkbox' name='remember' />";
                }else{
                    echo "<input type='checkbox' name='remember' />";
                }

            ?>  Remember me
            <br>

            <label>Login</label>
            <input name = "login" type="submit" value="Login">
            <P>Didn't sign up? <a  href="./Registration.php">Sign Up</a> </p>
                <P>Looking for new admin registration? <a  href="./Add.php">Sing Up|<a  href="./Login.php">|Login</a> </p>
          
        </fieldset>
        <script type="text/javascript"></script>
    </form>

<?php include("./includes/Footer.php"); ?>