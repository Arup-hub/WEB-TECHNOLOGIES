<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>footer</title>
</head>
<body>
     <fieldset>
    <b>    
        <label >
            <p style="text-align:center;">Copyright © 2022</P>
        </label>
    </b>
</fieldset>
</body>
</html>