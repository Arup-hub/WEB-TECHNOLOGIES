function validateForm(myForm) {
 var name=document.myForm.name.value;
 var email=document.myForm.email.value;
 var username=document.myForm.username.value;
 var password=document.myForm.password.value;
  var confirm password =document.myForm.confirm password.value;
  var date of birth=document.myForm.date of birth.value;
 var haserror = 0;
  if (name == "") {
 
     document.getElementById("name_error").innerHTML="Name can't be blank";
     haserror = 1;
 
  }
   if (email == "") {
 
     document.getElementById("email_error").innerHTML="Email can't be blank";
     haserror = 1;
 
  }
    if (username == "") {
 
     document.getElementById("username_error").innerHTML="Username can't be blank";
     haserror = 1;
 
  }
  if (password == "") {
 
     document.getElementById("password_error").innerHTML="Password can't be blank";
     haserror = 1;
 
  }
  if (confirm password == "") {
 
     document.getElementById("confirm_password_error").innerHTML="Confirm Password can't be blank";
     haserror = 1;
 
  }
  if (gender == "") {
 
     document.getElementById("gender_error").innerHTML="Gender can't be blank";
     haserror = 1;
 
  }
  if (date of birth == "") {
 
     document.getElementById("date_of_birth_error").innerHTML="Date of Birth can't be blank";
     haserror = 1;
 
  }
   if (haserror==1){
    return false;
  }

  return true;
}
header("location:Registeation.php");